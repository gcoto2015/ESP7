package apps.globaloutreach;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

/**
 * Created by ptaylor on 6/24/15.
 */
public class CreateEventActivity extends Activity implements AdapterView.OnItemSelectedListener {

    private MultiSelectionSpinner spinner1;
    private Spinner spinner2;
    private Spinner spinner3;
    private String themes[];
    private String type[];
    private String occur[];

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_event_activity);
        themes = new String[]{"No Theme", "Educational", "Food", "Family", "Sports", "Music"};
        type = new String[]{"No Event Type", "Environmental", "Recycling", "Non-Profit", "Charity"};
        occur = new String[]{"Onetime", "Daily", "Weekly", "Monthly", "Yearly"};
        spinner1 = (MultiSelectionSpinner) findViewById(R.id.themesOptions);
        spinner1.setItems(themes);
        spinner2 = (Spinner) findViewById(R.id.eventType);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, type);
        spinner2.setAdapter(adapter);
        spinner3 = (Spinner) findViewById(R.id.eventOccur);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, occur);
        spinner3.setAdapter(adapter2);
    }

    public void onNothingSelected(AdapterView<?> arg){
    }

    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

        switch (position) {
            case 0:
                break;
        }
    }

}
